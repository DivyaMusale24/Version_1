# Chatbot

#Steps from last team
Make sure that you have Python installed (tip- don’t install the latest version as not all the packages used in the code are supported by the latest version)
Have an IDE installed, we used VS Code in our case
Find the latest code under NEU diverse supplier drive(nu.cps.supplierdiversity@gmail.com)
To keep everything separate from the local machine we created a virtual environment and ran our code there
To create a new virtual environment
Install environment: pip install virtualenv
Create a new environment: virtualenv myenv_name
Activate the environment: path_to_folder\myenv_name\Scripts\activate
Install all the required packages: pip install -r requirement.txt
To use the environment we created:
Activate the environment: chatbot\myenv_name\Scripts\activate
Run the Python code: python api.py
Run the index.html code to view the UI and get a response

Middleware git repo: https://github.com/JiangHuPZ/Chatbot
