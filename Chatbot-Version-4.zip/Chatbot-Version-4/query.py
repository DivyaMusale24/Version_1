import langchain
from pinecone import Pinecone, ServerlessSpec
import openai
import tiktoken
import nest_asyncio
import os
from langchain.document_loaders.sitemap import SitemapLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.embeddings.openai import OpenAIEmbeddings
from langchain_pinecone import PineconeVectorStore
from langchain.chains import RetrievalQA
from langchain.llms import OpenAI
import requests
from bs4 import BeautifulSoup

# Initialize necessary services and libraries
def initialize_services():
    nest_asyncio.apply()
    os.environ["OPENAI_API_KEY"] = "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"
    openai_api_key = "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"
    openai.api_key = openai_api_key
    embeddings = OpenAIEmbeddings(openai_api_key=openai_api_key)
    os.environ["PINECONE_API_KEY"] = "b4e65de3-453f-4c0f-9678-90d52767171b"
    pinecone_api_key = "b4e65de3-453f-4c0f-9678-90d52767171b"

    pc = Pinecone(api_key=pinecone_api_key)
    index = pc.Index("chatbotnew")
    return embeddings

def load_documents():
    urls = ['https://finance.northeastern.edu/tasks/find-vendor-information/learn-purchasing-guidelines-procure-to-pay/',
            'https://finance.northeastern.edu/tasks/find-vendor-information/learn-more-about-supplier-diversity',
            'https://finance.northeastern.edu/departments/procurement-services/',
            'https://facilities.northeastern.edu/departments/administration/working-with-us/',
            'https://huskycard.sites.northeastern.edu/become-a-vendor/']

    docs = []
    for url in urls:
        content = scrape_url(url)
        if content:
            doc_metadata = {'url': url}
            docs.append(Document(content, metadata=doc_metadata))
    return docs

def initialize_qa_chain(embeddings, docs):
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size = 1200,
        chunk_overlap  = 200,
        length_function = len,
    )
    docs_chunks = text_splitter.split_documents(docs)

    index_name = "chatbotnew"
    docsearch = PineconeVectorStore.from_documents(docs_chunks, embeddings, index_name=index_name)

    llm = OpenAI(model_name="gpt-4")
    qa_with_sources = RetrievalQA.from_chain_type(llm=llm, chain_type="stuff", retriever=docsearch.as_retriever(), return_source_documents=True)
    return qa_with_sources

def scrape_url(url):
    try:
        response = requests.get(url)
        if response.status_code == 200:
            return response.text
        else:
            print(f"Failed to retrieve content from {url}, status code: {response.status_code}")
            return None
    except Exception as e:
        print(f"An error occurred while trying to scrape {url}: {e}")
        return None

class Document:
    def __init__(self, content, metadata=None):
        self.page_content = content
        self.metadata = metadata if metadata is not None else {}
